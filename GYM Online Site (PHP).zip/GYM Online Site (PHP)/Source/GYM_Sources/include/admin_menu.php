 <br/> <hr> </br/>
<center>
	<a href="admin_index.php" class="btn btn-lg px-4 btn-outline-primary"> لیست کاربران </a>
	<a href="admin_coach.php" class="btn btn-lg px-4 btn-outline-primary"> لیست دوره ها </a>
	<a href="admin_registers.php" class="btn btn-lg px-4 btn-outline-primary">لیست ثبت نام ها</a>
	<a href="logout.php" class="btn btn-lg px-4 btn-outline-primary"> خروج از سایت </a>
	
	
</center>